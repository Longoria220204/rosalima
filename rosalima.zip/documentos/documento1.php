<div>
    <h3 class="text-uppercase fw-bold" style="color: var(--color8);">REGLAMENTO INTERNO</h3>
    <p style="color: var(--color1);"> <span class="mr-3"> <i class="fas fa-calendar-alt" aria-hidden="true"></i></span> 04/11/2024</p>
    <hr style="background-color: var(--color4);">
    <div>
        <iframe src="./public/files/REGLAMENTO_INTERNO_JP_2024 .pdf" width="100%" height="700" frameborder="0"></iframe>
    </div>
    <br>
</div>