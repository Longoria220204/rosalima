<div>
    <h3 class="text-uppercase fw-bold" style="color: var(--color8);">JORNADA FAMILIAR ROSALINA</h3>
    <p style="color: var(--color1);"> <span class="mr-3"> <i class="fas fa-calendar-alt" aria-hidden="true"></i></span> 10/01/2025</p>
    <hr style="background-color: var(--color4);">
    <div>
    <iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2FLALIANOS%2Fposts%2Fpfbid0r6LDHbRqYg7AdEeahDDjQ2a9844WdmTjTtDEt529nrFffRvmNLNp69ikMpeRqY7Gl&show_text=true&width=500" width="100%" height="600" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
    </div>
    <br>
</div>