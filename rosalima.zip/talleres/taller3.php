<h3 class="text-uppercase fw-bold" style="color: var(--color8);">FUTSAL: ¡Pasión por el deporte y el trabajo en equipo! </h3>
<p style="color: var(--color1);"> <span class="mr-3"> <i class="fas fa-calendar-alt" aria-hidden="true"></i></span> 04/11/2024</p>
<hr style="background-color: var(--color4);">
<div>
    <div>
        <div>En el Colegio Jean Piaget, el futsal es m&aacute;s que un deporte: es una experiencia que fomenta disciplina, compa&ntilde;erismo y liderazgo en cada jugada.</div>
        <div>&nbsp;</div>
        <div><strong>&nbsp;Deporte y valores: </strong>A trav&eacute;s del futsal, nuestros estudiantes desarrollan habilidades t&eacute;cnicas, aprenden a trabajar en equipo y fortalecen su esp&iacute;ritu competitivo mientras disfrutan de una actividad saludable y divertida.</div>
        <div>&nbsp;</div>
        <div style="text-align: center;"><strong>⚡ &iexcl;Vive la emoci&oacute;n del futsal y forma parte de un equipo que juega con el coraz&oacute;n!</strong></div>
    </div>
    <div>&nbsp;</div>
    <div>&nbsp;</div>
    <div>
        <center><video src="./public/video/Futsal_JP_a.mp4" autoplay muted controls="controls"  width="90%">
            </video></center>
    </div>
</div>