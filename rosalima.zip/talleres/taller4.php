<h3 class="text-uppercase fw-bold" style="color: var(--color8);">CAMBRIDGE</h3>
<p style="color: var(--color1);"> <span class="mr-3"> <i class="fas fa-calendar-alt" aria-hidden="true"></i></span> 04/11/2024</p>
<hr style="background-color: var(--color4);">
<div>
    <div>
        <div>En el Colegio Jean Piaget contamos con m&aacute;s de 4 a&ntilde;os de experiencia como centro oficial de preparaci&oacute;n para la <strong>Certificaci&oacute;n Cambridge.</strong></div>
        <div>Nuestro prop&oacute;sito es formar l&iacute;deres globales desde inicial hasta secundaria, asegurando que nuestros estudiantes dominen el ingl&eacute;s al culminar su etapa escolar.</div>
        <div>&nbsp;</div>
        <div style="text-align: center;"><strong>&iexcl;Prep&aacute;rate para un futuro sin l&iacute;mites!</strong><br /><strong>Domina el ingl&eacute;s y asegura un futuro brillante con nosotros.</strong></div>
    </div>
    <div>&nbsp;</div>
    <div>&nbsp;</div>
    <div>
        <center><video src="./public/video/005-TALLER-Cambridge - PRIMARIA Y SECUNDARIA.mp4" autoplay muted controls="controls" height="500">
            </video></center>
    </div>
</div>